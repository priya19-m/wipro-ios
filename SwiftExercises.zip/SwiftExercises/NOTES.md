# Written Answers

The code files contain only code. All explanations required by the tasks are here.

## Topic 2: Variables and Constants

**Task 1, step 5.** Assigning a new value to `studentName` gives:
`cannot assign to value: 'studentName' is a 'let' constant`.
A `let` constant cannot change after it is set, so the line is removed.

**Task 1, step 6.** Swift inferred `String`, `Int`, `Int`, `Double` and `Bool`, which are the expected types.

**Task 3, compiler errors in the original code**

1. `price = 300` : `price` is declared with `let`, so it cannot be reassigned. Fix: declare it with `var`.
2. `let total = price * quantity * taxRate` : `price * quantity` is `Int` and `taxRate` is `Double`. Swift never mixes them silently. Fix: `Double(price * quantity) * (1 + taxRate)`.
3. `title = 42` : `title` was inferred as `String`, so an `Int` cannot be assigned. Fix: assign a string.

## Topic 3: Operators and Expressions

**Task 3, predicted output**

| Line | Output | Reason |
|---|---|---|
| `7 / 2` | `3` | integer division drops the fraction |
| `7 % 2` | `1` | remainder |
| `-7 % 3` | `-1` | the remainder takes the sign of the left operand |
| `7.0 / 2` | `3.5` | floating point division |
| `10 - 2 * 3 + 4 / 2` | `6` | 10 - 6 + 2 |
| `5 > 3 && 2 > 4 \|\| true` | `true` | `&&` binds tighter, (true && false) \|\| true |
| `1 << 3` | `8` | shift left by three bits |
| `6 & 3, 6 \| 3, 6 ^ 3` | `2 7 5` | AND, OR, XOR |
| `x &+ 1` (UInt8 255) | `0` | overflow wraps around |

## Topic 5: Enumerations, Structures and Classes

The enum case is written `borrowed(by:dueIn:)`. The worksheet shows `dueIns`, which looks like a typo for `dueIn`.

**Task 3.** The error is on `c.increment()`: `cannot use mutating member on immutable value: 'c' is a 'let' constant`.
`increment()` is `mutating`, so it changes the struct itself. A struct is a value type, and a `let` struct cannot change any of its properties. Fix: `var c = Counter()`.

The class version has no problem because `b` holds a reference to the object. `let` only stops `b` from pointing at a different object. The object it points to can still change. Two class constants refer to the same object when `b === anotherB` prints `true`.

## Topic 6: Optionals

**Task 3, the two crashes**

1. `scores["Kiran"]!` : the dictionary has no key "Kiran", so the lookup returns `nil` and force unwrapping `nil` crashes.
2. `Int("12a")!` : "12a" is not a number, so the conversion returns `nil` and force unwrapping crashes.

The fixed version uses `if let` and prints a message when a value is missing.

## Topic 7: ARC

**Task 1, step 5.** With a strong `tenant`, each object keeps the other alive, so the reference count never reaches zero. With `weak var tenant`, the apartment does not add to the person's count, so when the variables are set to `nil` the counts reach zero and both `deinit` messages appear.

**Task 2.** The stored closure captures `self` strongly and `self` holds the closure, which is a cycle, so `deinit` never runs. The capture list `[weak self]` breaks it.

**Task 3, output**

```
before c
Box gone
end
```

The object has three strong references (`a`, `b`, `c`). It is only freed when the last one, `c`, is set to `nil`.

| Reference | Use when |
|---|---|
| `strong` | the default; the owner needs the object to stay alive |
| `weak` | the other object may be freed first, so the reference is optional and becomes `nil` automatically (delegates, a child pointing to its parent) |
| `unowned` | the other object always lives at least as long as this one, so the reference is never optional (a credit card pointing to its customer) |

## Topic 8: Functions

**Task 3.** Functions are first-class values: they can be stored in constants (`let double = makeMultiplier(2)`), passed as arguments (`apply(numbers, using: double)`) and returned from other functions (`makeMultiplier` returns a function), exactly like an `Int` or a `String`.

## Topic 9: Closures

**Task 2.** `onTap` stores the closure in `handlers`, so the closure is called after `onTap` has already returned. A closure that outlives the function it was passed to must be marked `@escaping`.

**Task 3.** Output: `1 2 1 3`. Each call to `makeCounter()` creates a new `count` variable, and the returned closure captures its own copy. `a` and `b` therefore keep separate counts.

## Topic 10: Protocols and Extensions

**Task 3.** With a class hierarchy, a `Duck` would have to pick one parent, `Bird` or `FishAnimal`, but it can both fly and swim. With protocols, a type adopts any number of abilities, and `Flyable & Swimmable` accepts exactly the types that have both. New abilities can be added without changing existing types, and structs can conform too, while inheritance is limited to classes and a single parent.

## Topic 11: Generics and Error Handling

**Task 1, step 5.** Calling `largest(in:)` with an array of a type that is not `Comparable` does not compile, with an error like `global function 'largest(in:)' requires that 'MyType' conform to 'Comparable'`. That call is left out of the code file so the file still compiles.

## Topic 12: Integrated Swift Programming

**Task 3.** Calling `printReport()` on a `Repository` of a type that is not `Describable` does not compile, with an error like `referencing instance method 'printReport()' on 'Repository' requires that 'Item' conform to 'Describable'`. That call is left out of the code file so the file still compiles.
